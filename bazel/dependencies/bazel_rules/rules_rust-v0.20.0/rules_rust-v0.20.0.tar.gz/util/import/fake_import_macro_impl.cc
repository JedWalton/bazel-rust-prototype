//! A noop import macro handler.

int main(int argc, char** argv) { return 0; }
