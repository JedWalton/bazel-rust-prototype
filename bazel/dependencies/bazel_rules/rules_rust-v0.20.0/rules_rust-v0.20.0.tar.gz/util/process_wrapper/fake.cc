int main() {
    // Noop on purpose.
    return 0;
}