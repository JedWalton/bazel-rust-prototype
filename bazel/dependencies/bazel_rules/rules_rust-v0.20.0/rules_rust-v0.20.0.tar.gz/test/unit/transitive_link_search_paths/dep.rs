pub fn f() -> i64 {
    42
}
