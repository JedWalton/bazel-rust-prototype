use wrapper::wrap;

pub fn calls_wrap() {
    wrap();
}
