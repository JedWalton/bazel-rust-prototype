use second::fun;

fn main() {
    fun()
}
