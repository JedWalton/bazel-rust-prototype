pub fn first_fun() -> u8 {
    4 // chosen by fair dice roll.
      // guaranteed to be random.
}
