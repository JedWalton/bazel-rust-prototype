pub fn proc_macro_dep() -> i64 {
    42
}
