fn main() {
    println!("cargo:rustc-env=CONST=xyz");
}
