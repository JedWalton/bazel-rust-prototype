/// I want to link to [`Nonexistent`] but it doesn't exist!
pub fn foo() {}
