#include "second.h"

int get_two() {
    return 2;
}
