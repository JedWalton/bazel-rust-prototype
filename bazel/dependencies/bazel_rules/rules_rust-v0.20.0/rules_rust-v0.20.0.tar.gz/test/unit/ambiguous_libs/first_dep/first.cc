#include "first.h"

int get_one() {
    return 1;
}
