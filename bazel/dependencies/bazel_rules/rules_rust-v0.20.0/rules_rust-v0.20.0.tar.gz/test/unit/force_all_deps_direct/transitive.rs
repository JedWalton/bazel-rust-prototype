pub fn transitive_fn() {}
