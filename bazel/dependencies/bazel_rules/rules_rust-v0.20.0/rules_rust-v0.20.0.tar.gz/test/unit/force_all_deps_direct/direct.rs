use transitive::transitive_fn;

pub fn direct_fn() {
    transitive_fn();
}
