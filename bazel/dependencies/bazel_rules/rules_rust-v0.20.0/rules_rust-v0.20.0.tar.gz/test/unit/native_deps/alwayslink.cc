extern "C" int alwayslink() { return 42; }
