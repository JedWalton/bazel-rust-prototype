pub fn main() {
    dbg!(42);
}
