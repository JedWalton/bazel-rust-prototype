pub fn lib() {
    println!("Hello, Rust lib!");
}
