#include <stdio.h>

void lib() {
    printf("Hello, C lib!");
}
