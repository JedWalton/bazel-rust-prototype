#include <stdint.h>

extern "C" {
int32_t foo() { return 42; }
}
