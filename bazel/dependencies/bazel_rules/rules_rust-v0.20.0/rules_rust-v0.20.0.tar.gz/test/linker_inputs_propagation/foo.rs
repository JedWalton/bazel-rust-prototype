pub fn foo() -> i32 {
    42
}
