#[cfg(test)]
pub(crate) fn extra_test_fn() -> u32 {
    100
}
