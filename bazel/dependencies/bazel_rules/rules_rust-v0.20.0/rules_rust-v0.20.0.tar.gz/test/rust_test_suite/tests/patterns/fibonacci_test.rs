use math_lib::fibonacci;

#[test]
fn fibonacci_test() {
    assert_eq!(fibonacci(6), 13);
}
