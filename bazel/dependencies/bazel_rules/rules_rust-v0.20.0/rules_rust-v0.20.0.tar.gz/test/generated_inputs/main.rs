mod src;
fn main() {
    println!("{}", &src::forty_two());
}
