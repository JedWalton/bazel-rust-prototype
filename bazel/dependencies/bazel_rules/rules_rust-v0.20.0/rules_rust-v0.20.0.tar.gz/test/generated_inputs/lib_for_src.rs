pub fn forty_two() -> i32 {
    42
}
