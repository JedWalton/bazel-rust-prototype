#[cfg(test)]
pub fn foo() -> &'static str {
    "foo"
}