//! This is to test that the folder structure is properly preserved
