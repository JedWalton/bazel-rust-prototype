#include "return_zero.h"

int return_zero() { return 0; }
