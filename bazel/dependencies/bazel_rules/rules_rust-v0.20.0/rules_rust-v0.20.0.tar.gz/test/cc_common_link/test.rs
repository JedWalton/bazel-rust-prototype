#[test]
fn test() {
    assert_eq!(43, rdep::rdep());
}
