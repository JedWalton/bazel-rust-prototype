struct RustStruct{};

extern "C" RustStruct MakeRustStruct();

