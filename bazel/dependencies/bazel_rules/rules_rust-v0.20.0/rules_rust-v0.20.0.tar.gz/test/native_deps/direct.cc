#include "direct.h"

RustStruct MakeRustStruct() {
  RustStruct result;
  return result;
}
