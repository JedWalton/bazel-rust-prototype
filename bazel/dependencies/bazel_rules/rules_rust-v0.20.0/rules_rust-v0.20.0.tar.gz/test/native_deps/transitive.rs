#[repr(C)]
pub struct RustStruct {}
