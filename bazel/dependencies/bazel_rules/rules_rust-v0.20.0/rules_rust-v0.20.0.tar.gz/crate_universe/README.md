# Crate Universe

`crate_universe` is a collection of tools which use [Cargo][cargo] to generate build targets for [Bazel][bazel].

## [Documentation][docs]

For detailed documentation. See https://bazelbuild.github.io/rules_rust/crate_universe.html

[cargo]: https://doc.rust-lang.org/cargo/
[bazel]: https://bazel.build/
[docs]: https://bazelbuild.github.io/rules_rust/crate_universe.html
